import os
import subprocess

# Paths to the required directories
SDF_DIR = "SDF"
PDBQT_DIR = "PDBQT"

# Create PDBQT directory if it doesn't exist
os.makedirs(PDBQT_DIR, exist_ok=True)

# Function to convert SDF to PDBQT using Open Babel
def convert_sdf_to_pdbqt(sdf_file, pdbqt_file):
    command = ["obabel", sdf_file, "-O", pdbqt_file]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode == 0:
        print(f"Successfully converted {sdf_file} to {pdbqt_file}")
    else:
        print(f"Failed to convert {sdf_file} to {pdbqt_file}")
        print(result.stderr)

# Iterate over each SDF file in the SDF directory
for sdf_file in os.listdir(SDF_DIR):
    if sdf_file.endswith(".sdf"):
        sdf_path = os.path.join(SDF_DIR, sdf_file)
        pdbqt_file = os.path.splitext(sdf_file)[0] + ".pdbqt"
        pdbqt_path = os.path.join(PDBQT_DIR, pdbqt_file)
        convert_sdf_to_pdbqt(sdf_path, pdbqt_path)

print("Conversion completed.")
import os
import subprocess
import shutil
import logging
from pathlib import Path
import wget

logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')

def run_command(cmd, desc, input_text=None):
    """Run command with optional input text for interactive commands."""
    try:
        logging.info(f"Starting: {desc}")
        
        if input_text:
            process = subprocess.Popen(
                cmd,
                shell=True,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            stdout, stderr = process.communicate(input=input_text)  # Remove timeout
            if process.returncode != 0:
                raise subprocess.CalledProcessError(process.returncode, cmd, stdout, stderr)
        else:
            result = subprocess.run(
                cmd,
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )  # Remove timeout
            
        logging.info(f"Completed: {desc}")
        return True
        
    except subprocess.CalledProcessError as e:
        logging.error(f"Error in {desc}:")
        logging.error(f"Command: {cmd}")
        logging.error(f"Return code: {e.returncode}")
        logging.error(f"Output: {e.output}")
        logging.error(f"Error: {e.stderr}")
        return False


def download_mdp_files(simulation_dir):
    """Download MDP files using wget."""
    mdp_files = {
        'ions.mdp': 'http://www.mdtutorials.com/gmx/lysozyme/Files/ions.mdp',
        'minim.mdp': 'http://www.mdtutorials.com/gmx/lysozyme/Files/minim.mdp',
        'nvt.mdp': 'http://www.mdtutorials.com/gmx/lysozyme/Files/nvt.mdp',
        'npt.mdp': 'http://www.mdtutorials.com/gmx/lysozyme/Files/npt.mdp',
        'md.mdp': 'http://www.mdtutorials.com/gmx/lysozyme/Files/md.mdp'
    }
    
    for filename, url in mdp_files.items():
        output_path = os.path.join(simulation_dir, filename)
        if not os.path.exists(output_path):
            try:
                wget.download(url, output_path)
                logging.info(f"\nDownloaded {filename}")
            except Exception as e:
                logging.error(f"Failed to download {filename}: {e}")
                raise

def run_md_simulation(complex_path, run_interactive=False):
    complex_name = os.path.basename(complex_path).replace('.pdb', '')
    base_dir = os.path.abspath('MD-Simulations')
    simulation_dir = os.path.join(base_dir, complex_name)
    checkpoint_file = os.path.join(simulation_dir, 'checkpoint.txt')
    
    try:
        # Create simulation directory
        os.makedirs(simulation_dir, exist_ok=True)
        
        # Copy complex file
        dest_pdb = os.path.join(simulation_dir, os.path.basename(complex_path))
        shutil.copy2(complex_path, dest_pdb)
        
        # Initialize checkpoint file
        if not os.path.exists(checkpoint_file):
            with open(checkpoint_file, 'w') as f:
                f.write('')
        
        # Download MDP files
        download_mdp_files(simulation_dir)
        
        # Change to simulation directory
        original_dir = os.getcwd()
        os.chdir(simulation_dir)
        
        try:
            # Define MD simulation commands
            commands = [
                (f'grep -v HOH {complex_name}.pdb > {complex_name}_clean.pdb', "Removing HOH", None),
                (f'gmx pdb2gmx -f {complex_name}_clean.pdb -o {complex_name}_processed.gro -water spce -ignh', "Running pdb2gmx", "1\n1\n"),  # Select AMBER99SB-ILDN & TIP3P
                (f'gmx editconf -f {complex_name}_processed.gro -o {complex_name}_newbox.gro -c -d 1.0 -bt cubic', "Creating box", None),
                (f'gmx solvate -cp {complex_name}_newbox.gro -cs spc216.gro -o {complex_name}_solv.gro -p topol.top', "Adding solvent", None),
                (f'gmx grompp -f ions.mdp -c {complex_name}_solv.gro -p topol.top -o ions.tpr', "Preparing ions", None),
                (f'gmx genion -s ions.tpr -o {complex_name}_solv_ions.gro -p topol.top -pname NA -nname CL -neutral', "Adding ions", "13\n"),  # Select SOL
                (f'gmx grompp -f minim.mdp -c {complex_name}_solv_ions.gro -p topol.top -o em.tpr', "Preparing minimization", None),
                ('gmx mdrun -v -deffnm em -nb gpu', "Running minimization", None),
                (f'gmx grompp -f nvt.mdp -c em.gro -r em.gro -p topol.top -o nvt.tpr', "Preparing NVT", None),
                ('gmx mdrun -deffnm nvt -v -nb gpu -gpu_id 0 -nt 16 -pinoffset 0 -ntomp 8 -pme gpu -bonded gpu -update gpu -notunepme -dlb yes', "Running NVT", None),
                (f'gmx grompp -f npt.mdp -c nvt.gro -r nvt.gro -t nvt.cpt -p topol.top -o npt.tpr', "Preparing NPT", None),
                ('gmx mdrun -deffnm npt -v -nb gpu -gpu_id 0 -nt 16 -pinoffset 0 -ntomp 8 -pme gpu -bonded gpu -update gpu -notunepme -dlb yes', "Running NPT", None),
                (f'gmx grompp -f md.mdp -c npt.gro -t npt.cpt -p topol.top -o md_0_1.tpr', "Preparing MD", None),
                ('gmx mdrun -deffnm md_0_1 -v -nb gpu -gpu_id 0 -nt 16 -pinoffset 0 -ntomp 8 -pme gpu -bonded gpu -update gpu -notunepme -dlb yes', "Running MD", None)
            ]
            
            # Commands requiring input
            input_commands = [
                ('echo "10 0" | gmx energy -f em.edr -o potential.xvg', "Creating potential energy plot"),
                ('echo "16 0" | gmx energy -f nvt.edr -o temperature.xvg', "Creating temperature plot"),
                ('echo "24 0" | gmx energy -f npt.edr -o density.xvg', "Creating density plot"),
                ('echo "1 0" | gmx trjconv -s md_0_1.tpr -f md_0_1.xtc -o md_0_1_noPBC.xtc -pbc mol -center', "Removing PBC"),
                ('echo "4 4" | gmx rms -s md_0_1.tpr -f md_0_1_noPBC.xtc -o rmsd.xvg -tu ns', "Calculating RMSD"),
                ('echo "4 4" | gmx rms -s em.tpr -f md_0_1_noPBC.xtc -o rmsd_xtal.xvg -tu ns', "Calculating crystal RMSD"),
                ('echo "1" | gmx gyrate -s md_0_1.tpr -f md_0_1_noPBC.xtc -o gyrate.xvg', "Calculating radius of gyration")
            ]
            
            # Read checkpoint file
            with open(checkpoint_file, 'r') as f:
                completed_steps = set(f.read().splitlines())
            
            # Run regular commands
            for cmd, desc, input_text in commands:
                if desc in completed_steps:
                    logging.info(f"Skipping completed step: {desc}")
                    continue
                
                if run_interactive and input_text:
                    continue  # Skip interactive commands if not in interactive mode
                
                if not run_command(cmd, desc, input_text):
                    logging.error(f"Failed at step: {desc}")
                    return False
                
                with open(checkpoint_file, 'a') as f:
                    f.write(f"{desc}\n")
            
            # Run input commands if in interactive mode
            if run_interactive:
                for cmd, desc in input_commands:
                    if desc in completed_steps:
                        logging.info(f"Skipping completed step: {desc}")
                        continue
                    
                    if not run_command(cmd, desc):
                        logging.error(f"Failed at step: {desc}")
                        return False
                    
                    with open(checkpoint_file, 'a') as f:
                        f.write(f"{desc}\n")
                    
            return True
            
        finally:
            os.chdir(original_dir)
            
    except Exception as e:
        logging.error(f"Setup error for {complex_name}: {str(e)}")
        return False

def main():
    os.makedirs('MD-Simulations', exist_ok=True)
    complexes_dir = Path('Complexes')
    
    print("Select an option:")
    print("1. Run non-interactive commands")
    print("2. Run interactive commands")
    choice = input("Enter your choice (1 or 2): ").strip()
    
    run_interactive = choice == '2'
    
    for complex_file in complexes_dir.glob('*.pdb'):
        logging.info(f"\nProcessing {complex_file.name}")
        try:
            if run_md_simulation(str(complex_file), run_interactive):
                logging.info(f"Successfully completed {complex_file.name}")
            else:
                logging.error(f"Failed to process {complex_file.name}")
        except Exception as e:
            logging.error(f"Error processing {complex_file.name}: {e}")

if __name__ == "__main__":
    main()
import os
import subprocess
import time
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed

RECEPTOR = "2n0a.pdbqt"
LIGANDS_DIR = "PDBQT"
OUT_DIR = "OUT"
LOG_DIR = "LOG"
CONFIG_DIR = "Config"
VINA_PATH = "./vina"

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

def read_config(config_file):
    config = {}
    with open(config_file, 'r') as file:
        for line in file:
            line = line.strip()
            if '=' in line:
                key, value = line.split('=', 1)
                config[key.strip()] = value.strip()
    return config

def print_separator():
    print("=" * 75)

def run_vina(ligand_file, config, CONFIG_NAME):
    ligand_path = os.path.join(LIGANDS_DIR, ligand_file)
    print_separator()
    print(f"Processing ligand file: {ligand_path}")

    LIGAND_NAME = os.path.splitext(ligand_file)[0]
    OUTPUT = os.path.join(OUT_DIR, f"OUT_{LIGAND_NAME}_from_{CONFIG_NAME}.pdbqt")
    LOG = os.path.join(LOG_DIR, f"LOG_{LIGAND_NAME}_from_{CONFIG_NAME}.txt")

    vina_command = [
        VINA_PATH,
        "--receptor", RECEPTOR,
        "--ligand", ligand_path,
        "--out", OUTPUT,
        "--log", LOG,
        "--center_x", config["center_x"],
        "--center_y", config["center_y"],
        "--center_z", config["center_z"],
        "--size_x", config["size_x"],
        "--size_y", config["size_y"],
        "--size_z", config["size_z"]
    ]
    print(f"Running: {' '.join(vina_command)}")
    result = subprocess.run(vina_command, capture_output=True, text=True)

    if result.returncode == 0:
        print(f"Vina run for {LIGAND_NAME} completed successfully.")
        print(f"Output saved to: {OUTPUT}")
        print(f"Log saved to: {LOG}")
    else:
        print(f"Vina run for {LIGAND_NAME} failed. Please check the log file for details.")
        print(result.stderr)

    return LOG

def parse_log(log_file):
    results = []
    with open(log_file, 'r') as file:
        for line in file:
            if line.strip() and line.split()[0].isdigit():
                parts = line.split()
                mode = int(parts[0])
                affinity = float(parts[1])
                rmsd_lb = float(parts[2])
                rmsd_ub = float(parts[3])
                results.append((mode, affinity, rmsd_lb, rmsd_ub))
    return results

start_time = time.time()
summary_data = []

num_threads = os.cpu_count()

for config_file in os.listdir(CONFIG_DIR):
    if config_file.endswith(".txt"):
        config_path = os.path.join(CONFIG_DIR, config_file)
        print_separator()
        print(f"Processing config file: {config_path}")
        print_separator()

        CONFIG_NAME = os.path.splitext(config_file)[0]

        config = read_config(config_path)

        required_keys = ["center_x", "center_y", "center_z", "size_x", "size_y", "size_z"]
        missing_keys = [key for key in required_keys if key not in config]
        if missing_keys:
            print(f"ERROR: {', '.join(missing_keys)} are not defined in {config_path}")
            continue

        print(f"Center coordinates: ({config['center_x']}, {config['center_y']}, {config['center_z']})")
        print(f"Box size: ({config['size_x']}, {config['size_y']}, {config['size_z']})")

        ligand_files = [ligand_file for ligand_file in os.listdir(LIGANDS_DIR) if ligand_file.endswith(".pdbqt")]
        total_iterations = len(ligand_files)
        completed_iterations = 0

        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            futures = [executor.submit(run_vina, ligand_file, config, CONFIG_NAME) for ligand_file in ligand_files]
            for future in as_completed(futures):
                log_file = future.result()
                results = parse_log(log_file)
                for result in results:
                    mode, affinity, rmsd_lb, rmsd_ub = result
                    summary_data.append([CONFIG_NAME, os.path.basename(log_file).split('_')[1], mode, affinity, rmsd_lb, rmsd_ub])
                completed_iterations += 1
                elapsed_time = time.time() - start_time
                remaining_iterations = total_iterations - completed_iterations
                print(f"\nElapsed time: {elapsed_time:.2f} seconds")
                print(f"Remaining iterations: {remaining_iterations}\n")

summary_data.sort(key=lambda x: x[3])

print_separator()
print("Top 3 results for each pocket:")
print_separator()
pockets = set(row[0] for row in summary_data)
for pocket in pockets:
    pocket_data = [row for row in summary_data if row[0] == pocket]
    print(f"Pocket: {pocket}")
    print(f"{'PubChem CID':<15} {'Mode':<5} {'Affinity':<10} {'RMSD LB':<10} {'RMSD UB':<10}")
    for row in pocket_data[:3]:
        print(f"{row[1]:<15} {row[2]:<5} {row[3]:<10} {row[4]:<10} {row[5]:<10}")
    print_separator()

print("Top 3 results overall:")
print_separator()
print(f"{'Pocket':<15} {'PubChem CID':<15} {'Mode':<5} {'Affinity':<10} {'RMSD LB':<10} {'RMSD UB':<10}")
for row in summary_data[:3]:
    print(f"{row[0]:<15} {row[1]:<15} {row[2]:<5} {row[3]:<10} {row[4]:<10} {row[5]:<10}")

csv_file = "docking_summary.csv"
with open(csv_file, 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Pocket", "PubChem CID", "Mode", "Affinity", "RMSD LB", "RMSD UB"])
    writer.writerows(summary_data)

print(f"\nSummary saved to {csv_file}")
print_separator()
input("Press Enter to exit")
import os
import requests
import time

pubchem_ids = [
    135441816,
    162660072,
    2726228,
    46881231
]

N = 20

SDF_DIR = "SDF"

os.makedirs(SDF_DIR, exist_ok=True)

def download_sdf(pubchem_id, sdf_file):
    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/CID/{pubchem_id}/record/SDF/?record_type=3d"
    response = requests.get(url)
    if response.status_code == 200:
        with open(sdf_file, 'wb') as file:
            file.write(response.content)
        print(f"Successfully downloaded {sdf_file}")
    elif response.status_code == 404:
        print(f"Compound {pubchem_id} does not have a 3D structure available. Skipping download.")
    else:
        print(f"Failed to download {sdf_file}. Status code: {response.status_code}")

def get_similar_compounds(pubchem_id, n):
    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/fastsimilarity_3d/cid/{pubchem_id}/cids/JSON?Threshold=95&MaxRecords={n}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data.get('IdentifierList', {}).get('CID', [])
    else:
        print(f"Failed to get similar compounds for {pubchem_id}. Status code: {response.status_code}")
        print(response.text)
        return []

def get_substructure_matches(pubchem_id, n):
    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/fastsubstructure/cid/{pubchem_id}/cids/JSON?MaxRecords={n}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data.get('IdentifierList', {}).get('CID', [])
    else:
        print(f"Failed to get substructure matches for {pubchem_id}. Status code: {response.status_code}")
        print(response.text)
        return []

for pubchem_id in pubchem_ids:
    sdf_file = os.path.join(SDF_DIR, f"{pubchem_id}.sdf")
    if not os.path.exists(sdf_file):
        download_sdf(pubchem_id, sdf_file)
        time.sleep(5)  
    else:
        print(f"{sdf_file} already exists. Skipping download.")

    similar_compounds = get_similar_compounds(pubchem_id, N)
    for similar_id in similar_compounds:
        sdf_file = os.path.join(SDF_DIR, f"{similar_id}.sdf")
        if not os.path.exists(sdf_file):
            download_sdf(similar_id, sdf_file)
            time.sleep(5)
        else:
            print(f"{sdf_file} already exists. Skipping download.")

    substructure_matches = get_substructure_matches(pubchem_id, N)
    for substructure_id in substructure_matches:
        sdf_file = os.path.join(SDF_DIR, f"{substructure_id}.sdf")
        if not os.path.exists(sdf_file):
            download_sdf(substructure_id, sdf_file)
            time.sleep(5)
        else:
            print(f"{sdf_file} already exists. Skipping download.")

print("Download completed.")
import os
from pathlib import Path
import subprocess
from datetime import datetime

def extract_model_1(pdb_content):
    """Extract only Model 1 from PDB content."""
    model_1_content = []
    in_model_1 = False
    
    for line in pdb_content.split('\n'):
        if line.startswith('MODEL        1'):
            in_model_1 = True
        elif line.startswith('MODEL '):
            in_model_1 = False
        elif line.startswith('ENDMDL'):
            if in_model_1:
                model_1_content.append(line)
            break
        elif in_model_1 or not line.startswith('MODEL'):
            model_1_content.append(line)
            
    return '\n'.join(model_1_content)

def create_complexes():
    print("\n" + "="*50)
    print(f"Starting complex creation process at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*50 + "\n")

    # Create Complexes directory if it doesn't exist
    if not os.path.exists('Complexes'):
        os.makedirs('Complexes')
        print("Created Complexes directory")

    # Path to receptor
    receptor_path = '2n0a.pdbqt'
    print(f"Using receptor: {receptor_path}")
    
    # Get all ligands from Top folder
    ligand_dir = Path('Top')
    ligand_files = list(ligand_dir.glob('*.pdbqt'))
    total_ligands = len(ligand_files)
    print(f"Found {total_ligands} ligands to process\n")

    for idx, ligand_file in enumerate(ligand_files, 1):
        print(f"Processing [{idx}/{total_ligands}] {ligand_file.name}")
        ligand_name = ligand_file.stem
        complex_name = f"complex_{ligand_name}.pdb"
        complex_path = os.path.join('Complexes', complex_name)
        
        # Convert PDBQT to PDB
        subprocess.run(['obabel', receptor_path, '-O', 'receptor_temp.pdb'], capture_output=True)
        subprocess.run(['obabel', str(ligand_file), '-O', 'ligand_temp.pdb'], capture_output=True)
        
        # Read and filter for Model 1
        with open('receptor_temp.pdb', 'r') as f:
            receptor_content = extract_model_1(f.read())
        with open('ligand_temp.pdb', 'r') as f:
            ligand_content = extract_model_1(f.read())
            
        # Write filtered complex
        with open(complex_path, 'w') as f:
            f.write(receptor_content)
            f.write('\n')
            f.write(ligand_content)
        
        # Cleanup
        os.remove('receptor_temp.pdb')
        os.remove('ligand_temp.pdb')
        
        print(f"Created: {complex_name}")
        print("-"*50)

    print(f"\nProcess completed! {total_ligands} complexes created")
    print("="*50)

if __name__ == "__main__":
    create_complexes()
import subprocess
import datetime
import sys
from pathlib import Path

def run_and_log(command, log_file):
    print(f"Running: {command}")
    process = subprocess.run(['python', command], 
                           text=True,
                           capture_output=True)
    
    # Write to log file
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"\n{'='*50}\n")
        f.write(f"Running {command} at {datetime.datetime.now()}\n")
        f.write(f"{'='*50}\n")
        f.write(f"STDOUT:\n{process.stdout}\n")
        f.write(f"STDERR:\n{process.stderr}\n")
    
    # Also print to console
    print(process.stdout)
    if process.stderr:
        print(process.stderr)
    
    return process.returncode == 0

def main():
    # Create timestamp for log file
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = f"pipeline_log_{timestamp}.txt"
    
    # List of scripts to run in order
    scripts = [
        "download_sdf.py",
        "sdf_to_pdbqt.py",
        "perform_docking.py",
        "create_complex_from_ligand.py"
    ]
    
    # Run each script sequentially
    for script in scripts:
        print(f"\n{'='*50}")
        print(f"Starting {script}")
        print(f"{'='*50}\n")
        
        success = run_and_log(script, log_file)
        
        if not success:
            print(f"Error running {script}. Check {log_file} for details.")
            sys.exit(1)
    
    print(f"\nAll scripts completed successfully. Log saved to {log_file}")

if __name__ == "__main__":
    main()